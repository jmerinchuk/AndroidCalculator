/**************************************************************************
 * Program: Large Calculator
 * Programmer: Jayce Merinchuk
 * Date: June 25, 2018
 * Modified: January 22, 2019
 * Version: 2.0
 * Description: This program acts as a calculator with several basic
 * functions.  It was originally written as an assignment but has since
 * been modified and upgraded to include images, memory buttons, and
 * improved functionality in the numbers, equals, and operation buttons.
 *************************************************************************/
package com.example.jaycemerinchuk.largecalc;

// Import Libraries for use within the program
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import java.util.Locale;

/**************************************************************************
 * Class: MainActivity
 * Programmer: Jayce Merinchuk
 * Description: This is the only class for the program and handles all
 * functionality
 *************************************************************************/
public class MainActivity extends AppCompatActivity {

    // GUI Elements for use in the program
    TextView txtTotal;
    TextView txtRunning;
    TextView txtSignature;
    Button btnAdd;
    Button btnSubtract;
    Button btnMultiply;
    Button btnDivide;
    Button btnEquals;
    Button btnClear;

    // Global Variables for use within the program
    private static final String KEY_RUNNING_TOTAL = "keyrunningtotal";
    private static final String KEY_CURRENT_TOTAL = "keycurrenttotal";
    private static final String KEY_CURRENT_MEMORY = "keycurrentmemory";
    private static final String KEY_LAST_BUTTON_CLICKED = "keylastbuttonclicked";
    private static final String KEY_CURRENT_OPERATION = "keycurrentoperation";
    private String currentNumber;
    private String newRunning;
    private String currentOperation;
    private String currentMemory = "";
    private String num1;
    private String num2;
    private String resultStr;
    private String lastButtonClicked = "";
    private Double number1;
    private Double number2;
    private Double result;

    /**********************************************
     * Method: onCreate()
     * Description: This method is run when the
     * program starts and is used to initialize
     * values and find views (GUI elements) for
     * use in the program.
     *********************************************/
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Get Views for use within the program
        txtTotal = findViewById(R.id.txtTotal);
        txtRunning = findViewById(R.id.txtRunCalc);
        txtSignature = findViewById(R.id.txtSignature);
        btnAdd = findViewById(R.id.btnAdd);
        btnSubtract = findViewById(R.id.btnSubtract);
        btnMultiply = findViewById(R.id.btnMultiply);
        btnDivide = findViewById(R.id.btnDivide);
        btnEquals = findViewById(R.id.btnEquals);
        btnClear = findViewById(R.id.btnClear);

        // Restores values if the device had been rotated using savedInstanceState
        if (savedInstanceState != null) {
            txtRunning.setText(savedInstanceState.getString(KEY_RUNNING_TOTAL, ""));
            txtTotal.setText(savedInstanceState.getString(KEY_CURRENT_TOTAL, ""));
            lastButtonClicked = savedInstanceState.getString(KEY_LAST_BUTTON_CLICKED, "");
            currentOperation = savedInstanceState.getString(KEY_CURRENT_OPERATION, "");
            currentMemory = savedInstanceState.getString(KEY_CURRENT_MEMORY, "");
        }
    }

    /**********************************************
     * Method: btnBack()
     * Description: performs a backspace on the
     * calculator as long as string length is
     * greater than 0.
     * Created using Android:onClick
     **********************************************/
    public void btnBack(View view) {
        // Get the current number on screen
        currentNumber = txtTotal.getText().toString();

        // Verify string length is greater than 0
        if (currentNumber.length() > 0) {
            currentNumber = currentNumber.substring(0, currentNumber.length() - 1);
            txtTotal.setText(currentNumber);
            lastButtonClicked = "Back";
        }
    }

    /**********************************************
     * Method: btnMemory()
     * Description: If memory string is not null,
     * put memory in txtTotal TextView.
     * Created using Android:onClick
     **********************************************/
    public void btnMemory(View view) {
        if (currentMemory.length() > 0) {
            txtTotal.setText(currentMemory);
            lastButtonClicked = "M";
        }
    }

    /**********************************************
     * Method: btnMemoryAdd()
     * Description: Adds current txtTotal box number
     * to memory String.
     * Created using Android:onClick
     **********************************************/
    public void btnMemoryAdd(View view) {
        currentMemory = txtTotal.getText().toString();
        lastButtonClicked = "M+";
    }

    /**********************************************
     * Method: btnMemoryRemove()
     * Description: Removes current memory box number
     * from memory String.
     * Created using Android:onClick
     **********************************************/
    public void btnMemoryRemove(View view) {
        if (lastButtonClicked.equals("M")) {
            currentMemory = "";
            txtTotal.setText("");
            lastButtonClicked = "M-";
        }
    }

    /**********************************************
     * Method: btn0()
     * Description: Adds a "0" to the current
     * total box.
     * Created using Android:onClick
     **********************************************/
    public void btn0(View view) {
        // Allows you to push the last summed number to the running total and
        // continue entering a new number
        if (lastButtonClicked.equals("=")) {
            // Set current total in running total box and clear txtTotal
            txtRunning.setText(txtTotal.getText().toString());
            txtTotal.setText("");
        }

        // Verify the string is not longer than 9 numbers
        if (txtTotal.getText().toString().length() < 9) {
            // If current display is not "0", add a zero, else, do nothing.
            if (!txtTotal.getText().toString().equals("0")) {
                // set last button clicked for tracking
                lastButtonClicked = "0";
                // Set current Number
                currentNumber = txtTotal.getText().toString() + "0";
                // Add "0" to the current total Label
                txtTotal.setText(currentNumber);
            }
        }
    }

    /**********************************************
     * Method: btn1()
     * Description: Adds a "1" to the current
     * total box.
     * Created using Android:onClick
     **********************************************/
    public void btn1(View view) {
        // Allows you to push the last summed number to the running total and
        // continue entering a new number
        if (lastButtonClicked.equals("=")) {
            // Set current total in running total box and clear txtTotal
            txtRunning.setText(txtTotal.getText().toString());
            txtTotal.setText("");
        }

        // If current display is "0", erase the "0" then proceed adding number
        if (txtTotal.getText().toString().equals("0")) {
            txtTotal.setText("");
        }

        // Verify the string is not longer than 9 numbers
        if (txtTotal.getText().toString().length() < 9) {
            // set last button clicked for tracking
            lastButtonClicked = "1";
            // Set current Number
            currentNumber = txtTotal.getText().toString() + "1";
            // Add "1" to the current total Label
            txtTotal.setText(currentNumber);
        }
    }

    /**********************************************
     * Method: btn2()
     * Description: Adds a "2" to the current
     * total box.
     * Created using Android:onClick
     **********************************************/
    public void btn2(View view) {
        // Allows you to push the last summed number to the running total and
        // continue entering a new number
        if (lastButtonClicked.equals("=")) {
            // Set current total in running total box and clear txtTotal
            txtRunning.setText(txtTotal.getText().toString());
            txtTotal.setText("");
        }

        // If current display is "0", erase the "0" then proceed adding number
        if (txtTotal.getText().toString().equals("0")) {
            txtTotal.setText("");
        }

        // Verify the string is not longer than 9 numbers
        if (txtTotal.getText().toString().length() < 9) {
            // set last button clicked for tracking
            lastButtonClicked = "2";
            // Set current Number
            currentNumber = txtTotal.getText().toString() + "2";
            // Add "2" to the current total Label
            txtTotal.setText(currentNumber);
        }
    }

    /**********************************************
     * Method: btn3()
     * Description: Adds a "3" to the current
     * total box.
     * Created using Android:onClick
     **********************************************/
    public void btn3(View view) {
        // Allows you to push the last summed number to the running total and
        // continue entering a new number
        if (lastButtonClicked.equals("=")) {
            // Set current total in running total box and clear txtTotal
            txtRunning.setText(txtTotal.getText().toString());
            txtTotal.setText("");
        }

        // If current display is "0", erase the "0" then proceed adding number
        if (txtTotal.getText().toString().equals("0")) {
            txtTotal.setText("");
        }

        // Verify the string is not longer than 9 numbers
        if (txtTotal.getText().toString().length() < 9) {
            // set last button clicked for tracking
            lastButtonClicked = "3";
            // Set current Number
            currentNumber = txtTotal.getText().toString() + "3";
            // Add "3" to the current total Label
            txtTotal.setText(currentNumber);
        }
    }

    /**********************************************
     * Method: btn4()
     * Description: Adds a "4" to the current
     * total box
     **********************************************/
    public void btn4(View view) {
        // Allows you to push the last summed number to the running total and
        // continue entering a new number
        if (lastButtonClicked.equals("=")) {
            // Set current total in running total box and clear txtTotal
            txtRunning.setText(txtTotal.getText().toString());
            txtTotal.setText("");
        }

        // If current display is "0", erase the "0" then proceed adding number
        if (txtTotal.getText().toString().equals("0")) {
            txtTotal.setText("");
        }

        // Verify the string is not longer than 9 numbers
        if (txtTotal.getText().toString().length() < 9) {
            // set last button clicked for tracking
            lastButtonClicked = "4";
            // Set current Number
            currentNumber = txtTotal.getText().toString() + "4";
            // Add "4" to the current total Label
            txtTotal.setText(currentNumber);
        }
    }

    /**********************************************
     * Method: btn5()
     * Description: Adds a "5" to the current
     * total box.
     * Created using Android:onClick
     **********************************************/
    public void btn5(View view) {
        // Allows you to push the last summed number to the running total and
        // continue entering a new number
        if (lastButtonClicked.equals("=")) {
            // Set current total in running total box and clear txtTotal
            txtRunning.setText(txtTotal.getText().toString());
            txtTotal.setText("");
        }

        // If current display is "0", erase the "0" then proceed adding number
        if (txtTotal.getText().toString().equals("0")) {
            txtTotal.setText("");
        }

        // Verify the string is not longer than 9 numbers
        if (txtTotal.getText().toString().length() < 9) {
            // set last button clicked for tracking
            lastButtonClicked = "5";
            // Set current Number
            currentNumber = txtTotal.getText().toString() + "5";
            // Add "5" to the current total Label
            txtTotal.setText(currentNumber);
        }
    }

    /**********************************************
     * Method: btn6()
     * Description: Adds a "6" to the current
     * total box.
     * Created using Android:onClick
     **********************************************/
    public void btn6(View view) {
        // Allows you to push the last summed number to the running total and
        // continue entering a new number
        if (lastButtonClicked.equals("=")) {
            // Set current total in running total box and clear txtTotal
            txtRunning.setText(txtTotal.getText().toString());
            txtTotal.setText("");
        }

        // If current display is "0", erase the "0" then proceed adding number
        if (txtTotal.getText().toString().equals("0")) {
            txtTotal.setText("");
        }

        // Verify the string is not longer than 9 numbers
        if (txtTotal.getText().toString().length() < 9) {
            // set last button clicked for tracking
            lastButtonClicked = "6";
            // Set current Number
            currentNumber = txtTotal.getText().toString() + "6";
            // Add "6" to the current total Label
            txtTotal.setText(currentNumber);
        }
    }

    /**********************************************
     * Method: btn7()
     * Description: Adds a "7" to the current
     * total box.
     * Created using Android:onClick
     **********************************************/
    public void btn7(View view) {
        // Allows you to push the last summed number to the running total and
        // continue entering a new number
        if (lastButtonClicked.equals("=")) {
            // Set current total in running total box and clear txtTotal
            txtRunning.setText(txtTotal.getText().toString());
            txtTotal.setText("");
        }

        // If current display is "0", erase the "0" then proceed adding number
        if (txtTotal.getText().toString().equals("0")) {
            txtTotal.setText("");
        }

        // Verify the string is not longer than 9 numbers
        if (txtTotal.getText().toString().length() < 9) {
            // set last button clicked for tracking
            lastButtonClicked = "7";
            // Set current Number
            currentNumber = txtTotal.getText().toString() + "7";
            // Add "7" to the current total Label
            txtTotal.setText(currentNumber);
        }
    }

    /**********************************************
     * Method: btn8()
     * Description: Adds a "8" to the current
     * total box.
     * Created using Android:onClick
     **********************************************/
    public void btn8(View view) {
        // Allows you to push the last summed number to the running total and
        // continue entering a new number
        if (lastButtonClicked.equals("=")) {
            // Set current total in running total box and clear txtTotal
            txtRunning.setText(txtTotal.getText().toString());
            txtTotal.setText("");
        }

        // If current display is "0", erase the "0" then proceed adding number
        if (txtTotal.getText().toString().equals("0")) {
            txtTotal.setText("");
        }

        // Verify the string is not longer than 9 numbers
        if (txtTotal.getText().toString().length() < 9) {
            // set last button clicked for tracking
            lastButtonClicked = "8";
            // Set current Number
            currentNumber = txtTotal.getText().toString() + "8";
            // Add "8" to the current total Label
            txtTotal.setText(currentNumber);
        }
    }

    /**********************************************
     * Method: btn9()
     * Description: Adds a "9" to the current
     * total box.
     * Created using Android:onClick
     **********************************************/
    public void btn9(View view) {
        // Allows you to push the last summed number to the running total and
        // continue entering a new number
        if (lastButtonClicked.equals("=")) {
            // Set current total in running total box and clear txtTotal
            txtRunning.setText(txtTotal.getText().toString());
            txtTotal.setText("");
        }

        // If current display is "0", erase the "0" then proceed adding number
        if (txtTotal.getText().toString().equals("0")) {
            txtTotal.setText("");
        }

        // Verify the string is not longer than 9 numbers
        if (txtTotal.getText().toString().length() < 9) {
            // set last button clicked for tracking
            lastButtonClicked = "9";
            // Set current Number
            currentNumber = txtTotal.getText().toString() + "9";
            // Add "9" to the current total Label
            txtTotal.setText(currentNumber);
        }
    }


    /**********************************************
     * Method: btnClear()
     * Description: Clears all variables and
     * text.
     **********************************************/
    public void btnClear(View view) {
        // set last button clicked for tracking
        lastButtonClicked = "clear";
        // Clear the text boxes
        txtTotal.setText("");
        txtRunning.setText("");
    }


    /**********************************************
     * Method: btnEquals()
     * Description: Decision Maker for operation
     * used in math.
     **********************************************/
    public void btnEquals(View view) {
        // if txtTotal or txtRunning has no number, do not proceed, else convert numbers
        if (txtTotal.getText().toString().equals("") || txtRunning.getText().toString().equals("")) {
            txtRunning.setText("");
        }
        else {
            // Get the txtTotal number and the txtRunning number
            num1 = txtRunning.getText().toString();
            num2 = txtTotal.getText().toString();
            // Convert those strings to Double
            number1 = Double.parseDouble(num1);
            number2 = Double.parseDouble(num2);
            // Run the equalsFunction()
            equalsFunction(number1, number2);
        }
    }

    /**********************************************
     * Method: equalsFunction()
     * Description: Ensures we have two numbers
     * then uses a switch statement to choose
     * which operation to use.
     * Displays to 3 decimal points.
     * Will only display up to 21 characters.
     **********************************************/
    public void equalsFunction(double pNumber1, double pNumber2) {
        // if txtTotal has no number, do not proceed, else complete the calculation
        if (txtTotal.getText().toString().equals("") || txtRunning.getText().toString().equals("")) {
            txtRunning.setText("");
        }
        else {
            switch (currentOperation) {
                case "+":
                    result = pNumber1 + pNumber2;
                    break;
                case "-":
                    result = pNumber1 - pNumber2;
                    break;
                case "*":
                    result = pNumber1 * pNumber2;
                    break;
                case "/":
                    if (pNumber2 == 0) {
                        txtRunning.setText("0");
                    } else {
                        // Complete the Calculation
                        result = pNumber1 / pNumber2;
                    }
            }

            // Convert answer to string and display
            resultStr = String.format(Locale.CANADA, "%.3f", result);
            // Set last button clicked for tracking
            lastButtonClicked = "=";
            // if statement to ensure the string does not display more than 21 characters.
            if (resultStr.length() > 20) {
                resultStr = resultStr.substring(0, 19) + "...";
            }
                txtTotal.setText(resultStr);
        }
    }

    /**********************************************
     * Method: btnAdd()
     * Description: Adds the txtTotal number
     * with the running total number.
     **********************************************/
    public void btnAdd(View view) {
        // set last button clicked for tracking
        lastButtonClicked = "+";
        // set current Operation to "+"
        currentOperation = "+";

        // Add the number to the running calc box
        newRunning = txtTotal.getText().toString();
        // Show to running total
        txtRunning.setText(newRunning);
        // Clear the current number box
        txtTotal.setText("");
    }

    /**********************************************
     * Method: btnSubtract()
     * Description: Subtracts the txtTotal number
     * with the running total number.
     **********************************************/
    public void btnSubtract(View view) {
        // set last button clicked for tracking
        lastButtonClicked = "-";
        // set current Operation to "-"
        currentOperation = "-";

        // Add the number to the running calc box
        newRunning = txtTotal.getText().toString();
        // Show to running total
        txtRunning.setText(newRunning);
        // Clear the current number box
        txtTotal.setText("");
    }

    /**********************************************
     * Method: btnMultiply()
     * Description: Multiplies the txtTotal number
     * with the running total number.
     **********************************************/
    public void btnMultiply(View view) {
        // set last button clicked for tracking
        lastButtonClicked = "*";
        // set current Operation to "*"
        currentOperation = "*";
        // Add the number to the running calc box
        newRunning = txtTotal.getText().toString();
        // Show to running total
        txtRunning.setText(newRunning);
        // Clear the current number box
        txtTotal.setText("");
    }

        /**********************************************
         * Method: btnDivide()
         * Description: Divides the txtTotal number
         * with the running total number.
         **********************************************/
        public void btnDivide(View view) {
            // set last button clicked for tracking
            lastButtonClicked = "/";
            // set current Operation to "/"
            currentOperation = "/";
            // Add the number to the running calc box
            newRunning = txtTotal.getText().toString();
            // Show to running total
            txtRunning.setText(newRunning);
            // Clear the current number box
            txtTotal.setText("");
        }

    /**********************************************
     * Method: onSaveInstanceState()
     * Description: This method saves variables
     * and totals upon device rotation.
     **********************************************/
    @Override
    protected void onSaveInstanceState(Bundle savedInstanceState) {
        super.onSaveInstanceState(savedInstanceState);
        savedInstanceState.putString(KEY_RUNNING_TOTAL, txtRunning.getText().toString());
        savedInstanceState.putString(KEY_CURRENT_TOTAL, txtTotal.getText().toString());
        savedInstanceState.putString(KEY_CURRENT_MEMORY, currentMemory);
        savedInstanceState.putString(KEY_LAST_BUTTON_CLICKED, lastButtonClicked);
        savedInstanceState.putString(KEY_CURRENT_OPERATION, currentOperation);
    }

    /**********************************************
     * Method: onRestoreInstanceState()
     * Description: This method restores variables
     * and totals upon device rotation.
     **********************************************/
    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        txtRunning.setText(savedInstanceState.getString(KEY_RUNNING_TOTAL, ""));
        txtTotal.setText(savedInstanceState.getString(KEY_CURRENT_TOTAL, ""));
        lastButtonClicked = savedInstanceState.getString(KEY_LAST_BUTTON_CLICKED, "");
        currentOperation = savedInstanceState.getString(KEY_CURRENT_OPERATION, "");
        currentMemory = savedInstanceState.getString(KEY_CURRENT_MEMORY, "");
    }
}